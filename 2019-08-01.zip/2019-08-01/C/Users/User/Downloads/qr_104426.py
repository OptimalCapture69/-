import cv2
import time
import pyzbar


cap = cv2.VideoCapture(0)

def QR(frame):
	for barcode in pyzbar.decode(frame): # ищем QR-коды на кадре:
		x, y, w, h = barcode.rect # координаты и размеры QR-кода
		cx, cy = x + w // 2, y + h // 2 # координаты его центра
		data = barcode.data.decode('utf-8') # данные QR-кода
		print(data)
		# граффика
		cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
		cv2.putText(frame, data, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
		time.sleep(0.1)
		return(frame)

while True:
	img = cap.read()
	img = QR(img)

	cv2.imshow('result', flag)

	if cv2.waitKey(10) & 0xFF == ord('q'):
		break

cap.release()
cv2.destroyAllWindows()