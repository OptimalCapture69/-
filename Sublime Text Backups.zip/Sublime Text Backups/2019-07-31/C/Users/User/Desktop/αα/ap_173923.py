from pyzbar.pyzbar import decode
import cv2
import numpy as np

font = cv2.FONT_HERSHEY_SIMPLEX

def barcodeReader(image, bgr):
    gray_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    barcodes = decode(gray_img)
    ABCD = str(barcodes).split(', ')
    A=ABCD[0]
    return[str(barcodes[0]), A]


bgr = (8, 70, 208)

while (True):
    frame = cv2.imread('D:/QR.jpg')
    barcode = barcodeReader(frame, bgr)
    dt = barcode[0]#decrypted text
    print(barcode)
    cv2.putText(frame, dt,(128,353), font, 0.5,(0,0,255),1)
    cv2.imshow('Barcode reader', frame)
    code = cv2.waitKey(10)
    if code == ord('q'):
        break