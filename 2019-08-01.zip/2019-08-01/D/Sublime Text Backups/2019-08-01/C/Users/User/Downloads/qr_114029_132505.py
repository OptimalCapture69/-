import cv2
import time
from pyzbar import pyzbar
import numpy


def cv_size(img):
    return tuple(img.shape[1::-1])
sm=0
cap = cv2.VideoCapture(0)
frame = cap.read()
dpi=4.7
while True:
    frame, img = cap.read()

    for barcode in pyzbar.decode(img): # ищем QR-коды на кадре:
        x, y, w, h = barcode.rect # координаты и размеры QR-кода
        cx, cy = x + w // 2, y + h // 2 # координаты его центра
        data = barcode.data.decode('utf-8') # данные QR-кода
        
        if data == "1":
            sm=dpi/w
        print(data)
        print(sm*dpi)
        print(sm*w)
        # граффика
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
        cv2.putText(img, data, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    cv2.imshow('result', img)

    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()