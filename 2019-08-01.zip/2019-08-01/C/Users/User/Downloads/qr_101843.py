import cv2
from pyzbar import pyzbar


cap = cv2.VideoCapture(0) # 0 - встроенная камера ноутбука, 1 - следующая подключенная и т.д.

def QR(img):
for barcode in pyzbar.decode(img): # ищем QR-коды на кадре:
    x, y, w, h = barcode.rect # координаты и размеры QR-кода
    cx, cy = x + w // 2, y + h // 2 # координаты его центра
    data = barcode.data.decode('utf-8') # данные QR-кода
    return(data)

while True:
    flag, img = cap.read()
    QR(img)
    cv2.imshow('result', img)     # выводим на экран красивую картинку с надписями для контроля

    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()