import serial
import time

ArduinoSerial = serial.Serial("COM9", 9600)
time.sleep(2)

while 1:
    a = ArduinoSerial.readLine()
    print(a)
    a = str(a)[2:][:-5]
    print(a)
    glist = list(a.split(" "))
    print(glist)