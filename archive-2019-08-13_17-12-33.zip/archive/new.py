import serial
import time
from robolink import *
from robodk import *
RDK = Robolink()
ArduinoSerial = serial.Serial("COM9", 9600)
time.sleep(2)

glist=[0, 0 , 0]

while 1:
	if ArduinoSerial.inWaiting:
		a = ArduinoSerial.readline()
		a = str(a)[2:][:-5]
		glist = list(a.split(" "))

		robot = RDK.Item('Comau Racer 3 Base', ITEM_TYPE_ROBOT)     # retrieve the robot by name
		x=int(glist[0])
		y=int(glist[1])
		z=int(glist[2])
		target = RDK.Item('Target 1')
		try:
			approach = target.Pose()*transl(x, y, z + 150)
			robot.MoveJ(approach)
		except:
			approach = target.Pose()*transl(x, y, z + 150)
			robot.MoveJ(approach)