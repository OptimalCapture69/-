import serial
ser = serial.Serial('COM9', 9600)
while True:
    s = ser.readline