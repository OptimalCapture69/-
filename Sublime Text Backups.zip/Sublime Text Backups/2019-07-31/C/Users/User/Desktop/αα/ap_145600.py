from pyzbar import pyzbar
import argparse
import numpy as np
import cv2

image =cv2.imread("D:/QR2.jpg")
thresholded = cv2.cvtColor(mask,cv2.COLOR_GRAY2BGR)
inverted = 255-thresholded # black-in-white
barcodes = pyzbar.decode(inverted)
print (barcodes)