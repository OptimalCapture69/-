import cv2
import pyzbar as zbar
from PIL import Image

cv2.namedWindow("#iothack15")
cap = cv2.VideoCapture(0)
def scanner(dec):
	decode.decode(dec)
while True:
    ret, output = cap.read()
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY, dstCn=0)
    pil = Image.fromarray(gray)
    width, height = pil.size
    raw = pil.tobytes()
    image = zbar.Image(width, height, 'Y800', raw)
    scanner(image)
	
    for symbol in image:
        print ('decoded', symbol.type, 'symbol', '"%s"' % symbol.data)

    cv2.imshow("#iothack15", output)
    keypress = cv2.waitKey(1) & 0xFF
    if keypress == ord('q'):
    	break
cap.release()
cv2.destroyAllWindows()