from robodk import*
from robolink import*
RDK = Robolink()

robot = RDK.Item("KUKA KR 3 R540")
target = RDK.Item("Target 1")

while 1:
	try:
		i = int(input("первая координата: "))
		b = int(input("Вторая координата: "))
		c = int(input("Третья координата: "))


		approach = target.Pose()*transl(b, i, c)

		robot.MoveJ(approach)
	
	except Exception:
		i = int(input("первая координата: "))
		b = int(input("Вторая координата: "))
		c = int(input("Третья координата: "))

		approach = target.Pose()*transl(b, i, c)

		robot.MoveJ(approach)