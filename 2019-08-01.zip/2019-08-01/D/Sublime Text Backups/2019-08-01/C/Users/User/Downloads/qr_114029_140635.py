import cv2
import time
from pyzbar import pyzbar
import numpy as np


def cv_size(img):
    return tuple(img.shape[1::-1])

sm=0         
dpi=4.7     #Размер QR кода в сантиметрах

cap = cv2.VideoCapture(1)

hsv_min = np.array((53, 55, 147), np.uint8)
hsv_max = np.array((83, 160, 255), np.uint8)

while True:
    frame, img = cap.read()
    # преобразуем RGB картинку в HSV модель
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV )
    # применяем цветовой фильтр
    thresh = cv2.inRange(hsv, hsv_min, hsv_max)
    for barcode in pyzbar.decode(img): # ищем QR-коды на кадре:
        x, y, w, h = barcode.rect # координаты и размеры QR-кода
        cx, cy = x + w // 2, y + h // 2 # координаты его центра
        data = barcode.data.decode('utf-8') # данные QR-кода
        
        if data == "1":
            sm=dpi/w
        print(data)
        print(sm*dpi)
        print(sm*w)
        # граффика
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
        cv2.putText(img, data, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    
    moments = cv2.moments(thresh, 1)
    dM01 = moments['m01']
    dM10 = moments['m10']
    dArea = moments['m00']

    cv2.imshow('result', img)

    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()