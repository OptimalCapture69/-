from pyzbar.pyzbar import decode
import cv2
import numpy as np
import re

font = cv2.FONT_HERSHEY_SIMPLEX
def mean(numbers):
    return round(float(sum(numbers)) / max(len(numbers), 1))

def barcodeReader(image, bgr):
    gray_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    barcodes = decode(gray_img)
    ABCD = str(barcodes[1])
    ABCD = ABCD.replace("Point(", "")
    ABCD = ABCD.replace(")", "")
    ABCD = ABCD.split(", ")
    Ax=str(ABCD[0])[3:]
    print(Ax)
    Ay=str(ABCD[1])[2:]
    print(Ay)
    Cx=str(ABCD[4])[2:]
    print(Cx)
    Cy=str(ABCD[5])[2:]
    print(Cy)
    X=(int(Ax)+int(Cx))/2
    Y=(int(Ay)+int(Cy))/2
    print(ABCD)
    return[str(barcodes[0]), ABCD]


bgr = (8, 70, 208)

cap=videoCapture()

while (True):
    frame = cap.read()
    barcode = barcodeReader(frame, bgr)
    dt = barcode[0]#decrypted text
    cv2.putText(frame, dt,(128,353), font, 0.5,(0,0,255),1)
    cv2.imshow('Barcode reader', frame)
    code = cv2.waitKey(10)
    if code == ord('q'):
        break