from pyzbar.pyzbar import decode
import cv2
import numpy as np


def barcodeReader(image, bgr):
    gray_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    barcodes = decode(gray_img)

    for decodedObject in barcodes:
        points = decodedObject.polygon

        pts = np.array(points, np.int32)
        return(barcodes)
        

bgr = (8, 70, 208)

while (True):
    frame = cv2.imread('D:/QR.jpg')
    barcode = barcodeReader(frame, bgr)
    print(barcode)
    cv2.imshow('Barcode reader', frame)
    code = cv2.waitKey(10)
    if code == ord('q'):
        break