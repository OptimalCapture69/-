from pyzbar.pyzbar import decode
import cv2
import numpy as np

font = cv2.FONT_HERSHEY_SIMPLEX
def mean(numbers):
    return round(float(sum(numbers)) / max(len(numbers), 1))

def barcodeReader(image):
    gray_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    barcodes = decode(gray_img)
    ABCD = str(barcodes[1])
    ABCD = ABCD.replace("Point(", "")
    ABCD = ABCD.replace(")", "")
    return[str(barcodes[0]), ABCD]



cap=cv2.VideoCapture(0)

while (True):
    frame = cap.read()
    barcode = barcodeReader(frame)
    print(barcode) #decrypted text
    cv2.imshow('Barcode reader', frame)
    code = cv2.waitKey(10)
    if code == ord('q'):
        break