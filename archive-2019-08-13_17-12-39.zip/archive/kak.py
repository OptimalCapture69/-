def ada():
	glist = (5, 5, -5) 
	return (glist)