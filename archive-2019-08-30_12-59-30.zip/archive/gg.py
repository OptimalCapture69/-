from robodk import*
from robolink import*
RDK = Robolink()

robot = RDK.Item('KUKA KR 3 R540', True)
target = RDK.AddTarget("T1")
target.setAsCartesianTarget()
tp = target.Pose()
target.setPose(tp)
robot.MoveJ(target)
print(tp)
target.Delete()